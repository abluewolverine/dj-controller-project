# Particle-position simulation: spec and analyses

This document specifies the behavior of the particle-position simulator implemented in this repository and describes the analyses and experimental runs that should be executed on generated synthetic data. The goal is to give enough detail so a developer (or Copilot) can implement, validate, and analyse the model without additional clarification.

## Model

Overview
- The simulator models a single particle (or an effective single-particle wavefunction) moving on a discrete 1D lattice (positions indexed 0..L-1). The UI maps a simple composition (proton / neutron / electron counts) and a small set of environment parameters into initial conditions and effective model parameters.

State variables
- time t: integer time step (0..T)
- L: lattice length (number of discrete positions)
- psi_re[x], psi_im[x]: real and imaginary parts of the particle's wave amplitude at position x (for quantum mode)
- prob[x] = psi_re[x]^2 + psi_im[x]^2: probability mass function (PMF) over positions
- p_class[x]: classical probability of being at x for classical mode (a discrete probability vector)

Inputs / mapped parameters
- nProtons, nNeutrons, nElectrons: integer counts from the Controls panel. These are mapped to effective quantities used by the simulation, for example:
  - mass ~ f(nProtons, nNeutrons) (higher nucleon count → heavier effective mass → slower quantum dispersion)
  - chargeBias ~ g(nProtons, nElectrons) (introduces asymmetric drift under an external field E)
- E: external field (real number) — acts as a linear potential or a drift term
- temp: temperature (positive real) — used to set stochastic noise / classical diffusion rate or decoherence scaling
- mode: 'quantum' or 'classical' — selects update rules (complex amplitude unitary update vs. classical probability diffusion)
- T: number of timesteps to evolve the model
- decoherenceOverride: optional value in [0,1] to override automatic decoherence selection (0 = no decoherence, 1 = full decoherence)

Boundary conditions and initialization
- Boundary conditions: reflective or periodic (implementer choice; specify in code and document which is used). Default: reflective at edges (no flux beyond 0 and L-1).
- Initial condition: place an initial localized amplitude at a central position x0 (e.g., x0 = floor(L/2)). For composition > 0 the initial width may be slightly broader to reflect internal structure (small Gaussian width). For classical mode initialize p_class with same spatial profile.

Update rules
- Quantum mode (discrete-time Schrödinger-like update):
  - Use a simple tight-binding style update: psi_{t+1}[x] = A*psi_t[x] + B*(psi_t[x-1] + psi_t[x+1]) + potential-phase term from E and chargeBias
  - After update, compute prob[x] = psi_re^2 + psi_im^2 and normalize if needed.
  - Optionally apply decoherence: mix the probability distribution toward its diagonal (i.e., reduce off-diagonal coherence) by a factor decoherence in [0,1]. This can be implemented by applying a convex combination between the pure quantum density and a classical probability vector.

- Classical mode (stochastic diffusion / random walk):
  - At each timestep move probability mass according to a discrete diffusion operator: p_{t+1}[x] = (1 - alpha)*p_t[x] + alpha/2*(p_t[x-1] + p_t[x+1]) + drift from E
  - Optionally add thermal noise proportional to temp.

Numerical notes
- Use double precision floats where available for psi components.
- Take care with normalization to avoid floating-point drift; renormalize every step if needed.
- For visualization and reproducibility, store snapshots of psi_re, psi_im, prob (or p_class) at each time step or at a configured sampling interval.

Outputs
- Time-indexed PMF arrays prob[t][x] (or p_class[t][x]) for t=0..T
- Derived statistics per run: mean position mu(t), variance sigma^2(t), entropy H(t), participation ratio (1 / sum(prob^2)), and optionally phase information (wrapped into [-pi,pi])

## Analyses

The analyses section describes which model executions to run to produce datasets and which post-hoc analyses to perform on the synthetic outputs.

Design principles
- Run parameter sweeps systematically: vary one parameter while holding others fixed to quantify sensitivity.
- For stochastic parts of the model (classical diffusion, thermal noise, or stochastic decoherence), perform ensemble runs and report ensemble statistics (mean, std, and confidence intervals).

Recommended experiments (examples)
1) Baseline behavior (deterministic quantum propagation)
   - mode: quantum
   - nProtons/neutrons/electrons: (1,0,1) (simple small mass)
   - E: 0
   - temp: 300 (ignored for pure quantum)
   - decoherenceOverride: 0
   - T: 100
   - Runs: 1 (deterministic)
   - Outputs: prob[t][x], mu(t), sigma^2(t), participation ratio(t)

2) Classical diffusion baseline
   - mode: classical
   - same composition as (1)
   - temp: small (e.g., 300) used to set diffusion coefficient
   - T: 100
   - Runs: 200–500 (ensemble) to get stable averages
   - Outputs: ensemble-averaged prob[t][x], mu(t) ± std, variance ± std

3) Compare quantum vs classical spreading
   - Sweep mass (via nProtons+nNeutrons) across small set: {1, 2, 6, 12}
   - For each mass, run both modes with identical E and temp
   - Runs: quantum (1 run), classical (200 runs) or quantum (repeat with small randomized decoherence seeds to produce N~20 runs for uncertainty)
   - Analyses: compare mu(t), sigma^2(t), plot heatmaps side-by-side, quantify differences in spread rate (fit sigma^2(t) vs t curves), compute KL divergence between PMFs at selected timesteps

4) Decoherence sweep
   - mode: quantum with decoherence mixing parameter
   - decoherence values: [0, 0.01, 0.05, 0.1, 0.2, 0.5]
   - T: 100
   - Runs: repeat each decoherence value 20–50 times if stochastic decoherence is used; otherwise single run per value
   - Analyses: track reduction in interference fringes in prob[t][x], compute distance from classical ensemble (e.g., mean KL divergence over t), compute how quickly entropy increases with decoherence

5) Field (E) and drift experiments
   - Sweep E across a range (e.g., -10, -1, -0.1, 0, 0.1, 1, 10)
   - For each E, run both modes and examine net drift: mu(t) trend and steady-state displacement
   - Runs: classical (200 ensemble runs), quantum (deterministic or small ensemble if decoherence present)

Data collection and storage
- For each run save a compact representation:
  - meta.json: parameter set used for the run (mode, nProtons, nNeutrons, nElectrons, E, temp, decoherence, T, L)
  - prob.npy or prob.csv: prob[t][x] array (or compressed format)
  - stats.csv: per-timestep statistics (mu, variance, entropy, participation ratio)

Analyses to perform on stored results
- Per-run diagnostics: verify normalization at each t, compute time series of mu(t), sigma^2(t), H(t)
- Ensemble statistics: for stochastic runs compute mean and 95% CI for mu(t), sigma^2(t)
- Visualization:
  - Heatmap of prob[t][x] (time x position) for representative runs
  - Line plots of mu(t) and sigma^2(t) with ensemble shading
  - PMF table at final timestep and small line-plot of prob[x] for a chosen t
- Comparative metrics:
  - KL divergence between distributions P and Q at selected timesteps
  - L2 distance between PMFs
  - Spread-rate estimation: fit sigma^2(t) = a * t^b and report fitted parameters a, b (quantum spreading often shows b≈2 for ballistic, classical b≈1 for diffusive — use this to distinguish dynamics)

Reproducibility and recommendations
- Use fixed random seeds and record them in `meta.json` for any ensemble experiments.
- Keep lattice size L large enough to avoid boundary effects for the chosen T (or use periodic boundaries and document choice).
- When comparing quantum and classical outcomes, ensure the mapping from composition to mass/charge is documented and consistent across experiments.

Deliverables
- `spec.md` (this file) — describes the model and analyses
- Implementation code in `src/hooks/useSimulation.js` — should implement the model and produce the outputs described above
- Example analysis scripts (Python / Node) that load `prob` and `stats` files and produce the recommended visualizations and comparative metrics (not included here but recommended as follow-up)

If you'd like, I can also add a small `analysis/README.md` with runnable commands to reproduce the recommended experiments and example plotting code. Tell me which analyses you want automated first (e.g., quantum vs classical spread comparison, decoherence sweep) and I will add the scripts and a short runner.