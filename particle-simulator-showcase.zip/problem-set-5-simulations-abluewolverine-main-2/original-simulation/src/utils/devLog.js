const logs = [];
const listeners = new Set();

function notify() {
  const snapshot = logs.slice();
  listeners.forEach((cb) => {
    try { cb(snapshot); } catch (e) { /* ignore */ }
  });
}

export function pushLog(text, meta = {}) {
  const entry = { ts: new Date().toISOString(), text, meta };
  logs.push(entry);
  // keep size reasonable
  if (logs.length > 1000) logs.shift();
  notify();
}

export function getLogs() {
  return logs.slice();
}

export function clearLogs() {
  logs.length = 0;
  notify();
}

export function subscribeLogs(cb) {
  listeners.add(cb);
  try { cb(logs.slice()); } catch (e) {}
  return () => listeners.delete(cb);
}

export function downloadLogs() {
  return JSON.stringify(logs, null, 2);
}

const api = { pushLog, getLogs, clearLogs, subscribeLogs, downloadLogs };
export default api;
