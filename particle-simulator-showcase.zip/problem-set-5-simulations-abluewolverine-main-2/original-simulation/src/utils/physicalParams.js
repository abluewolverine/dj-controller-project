// Map physical composition (protons, neutrons, electrons) to simulation parameters
// such as mass, charge, step variance, bias and decoherence.
export default function physicalToSimParams({ nProtons = 1, nNeutrons = 0, nElectrons = 1, E = 0, temp = 300, scale = 1 }) {
  const mp = 1.0; // relative mass unit for proton
  const mn = 1.0; // relative mass unit for neutron
  const me = 0.00054; // relative mass unit for electron (much smaller)
  const eCharge = 1.0; // unit charge in simulation units

  const mass = mp * nProtons + mn * nNeutrons + me * nElectrons;
  const charge = eCharge * (nProtons - nElectrons);

  // noise / diffusion strength inversely proportional to mass, scaled by temperature
  const noiseScale = Math.max(1e-6, (temp / 300) * scale);
  const stepVariance = noiseScale / Math.max(mass, 1e-6);

  // bias from external field E (maps to probability bias in [-0.5,0.5])
  const driftFactor = 0.05; // tunable mapping constant
  const bias = Math.max(-0.5, Math.min(0.5, driftFactor * (charge * E) / Math.max(mass, 1e-6)));

  // decoherence: heavier/complex systems decohere faster; map to [0,1]
  const complexity = nProtons + nNeutrons + nElectrons;
  const decoherenceBase = Math.tanh(complexity / 50);
  const decoherenceMassFactor = Math.min(1, mass / 1000);
  const decoherence = Math.max(0, Math.min(1, decoherenceBase * (0.3 + 0.7 * decoherenceMassFactor)));

  return {
    mass,
    charge,
    stepVariance,
    bias,
    decoherence
  };
}
