// Minimal periodic table data for lookup by atomic number (protons)
// Includes name and symbol for Z = 1..118 and an optional commonMass (most abundant mass number)
// This dataset is a lightweight, local mapping used to display element/isotope names from (Z, N, e)

const elements = {
  1: { symbol: 'H', name: 'Hydrogen', commonMass: 1 },
  2: { symbol: 'He', name: 'Helium', commonMass: 4 },
  3: { symbol: 'Li', name: 'Lithium', commonMass: 7 },
  4: { symbol: 'Be', name: 'Beryllium', commonMass: 9 },
  5: { symbol: 'B', name: 'Boron', commonMass: 11 },
  6: { symbol: 'C', name: 'Carbon', commonMass: 12 },
  7: { symbol: 'N', name: 'Nitrogen', commonMass: 14 },
  8: { symbol: 'O', name: 'Oxygen', commonMass: 16 },
  9: { symbol: 'F', name: 'Fluorine', commonMass: 19 },
  10: { symbol: 'Ne', name: 'Neon', commonMass: 20 },
  11: { symbol: 'Na', name: 'Sodium', commonMass: 23 },
  12: { symbol: 'Mg', name: 'Magnesium', commonMass: 24 },
  13: { symbol: 'Al', name: 'Aluminium', commonMass: 27 },
  14: { symbol: 'Si', name: 'Silicon', commonMass: 28 },
  15: { symbol: 'P', name: 'Phosphorus', commonMass: 31 },
  16: { symbol: 'S', name: 'Sulfur', commonMass: 32 },
  17: { symbol: 'Cl', name: 'Chlorine', commonMass: 35 },
  18: { symbol: 'Ar', name: 'Argon', commonMass: 40 },
  19: { symbol: 'K', name: 'Potassium', commonMass: 39 },
  20: { symbol: 'Ca', name: 'Calcium', commonMass: 40 },
  21: { symbol: 'Sc', name: 'Scandium', commonMass: 45 },
  22: { symbol: 'Ti', name: 'Titanium', commonMass: 48 },
  23: { symbol: 'V', name: 'Vanadium', commonMass: 51 },
  24: { symbol: 'Cr', name: 'Chromium', commonMass: 52 },
  25: { symbol: 'Mn', name: 'Manganese', commonMass: 55 },
  26: { symbol: 'Fe', name: 'Iron', commonMass: 56 },
  27: { symbol: 'Co', name: 'Cobalt', commonMass: 59 },
  28: { symbol: 'Ni', name: 'Nickel', commonMass: 58 },
  29: { symbol: 'Cu', name: 'Copper', commonMass: 63 },
  30: { symbol: 'Zn', name: 'Zinc', commonMass: 64 },
  31: { symbol: 'Ga', name: 'Gallium', commonMass: 69 },
  32: { symbol: 'Ge', name: 'Germanium', commonMass: 74 },
  33: { symbol: 'As', name: 'Arsenic', commonMass: 75 },
  34: { symbol: 'Se', name: 'Selenium', commonMass: 79 },
  35: { symbol: 'Br', name: 'Bromine', commonMass: 80 },
  36: { symbol: 'Kr', name: 'Krypton', commonMass: 84 },
  37: { symbol: 'Rb', name: 'Rubidium' },
  38: { symbol: 'Sr', name: 'Strontium' },
  39: { symbol: 'Y', name: 'Yttrium' },
  40: { symbol: 'Zr', name: 'Zirconium' },
  41: { symbol: 'Nb', name: 'Niobium' },
  42: { symbol: 'Mo', name: 'Molybdenum' },
  43: { symbol: 'Tc', name: 'Technetium' },
  44: { symbol: 'Ru', name: 'Ruthenium' },
  45: { symbol: 'Rh', name: 'Rhodium' },
  46: { symbol: 'Pd', name: 'Palladium' },
  47: { symbol: 'Ag', name: 'Silver' },
  48: { symbol: 'Cd', name: 'Cadmium' },
  49: { symbol: 'In', name: 'Indium' },
  50: { symbol: 'Sn', name: 'Tin' },
  51: { symbol: 'Sb', name: 'Antimony' },
  52: { symbol: 'Te', name: 'Tellurium' },
  53: { symbol: 'I', name: 'Iodine' },
  54: { symbol: 'Xe', name: 'Xenon' },
  55: { symbol: 'Cs', name: 'Caesium' },
  56: { symbol: 'Ba', name: 'Barium' },
  57: { symbol: 'La', name: 'Lanthanum' },
  58: { symbol: 'Ce', name: 'Cerium' },
  59: { symbol: 'Pr', name: 'Praseodymium' },
  60: { symbol: 'Nd', name: 'Neodymium' },
  61: { symbol: 'Pm', name: 'Promethium' },
  62: { symbol: 'Sm', name: 'Samarium' },
  63: { symbol: 'Eu', name: 'Europium' },
  64: { symbol: 'Gd', name: 'Gadolinium' },
  65: { symbol: 'Tb', name: 'Terbium' },
  66: { symbol: 'Dy', name: 'Dysprosium' },
  67: { symbol: 'Ho', name: 'Holmium' },
  68: { symbol: 'Er', name: 'Erbium' },
  69: { symbol: 'Tm', name: 'Thulium' },
  70: { symbol: 'Yb', name: 'Ytterbium' },
  71: { symbol: 'Lu', name: 'Lutetium' },
  72: { symbol: 'Hf', name: 'Hafnium' },
  73: { symbol: 'Ta', name: 'Tantalum' },
  74: { symbol: 'W', name: 'Tungsten' },
  75: { symbol: 'Re', name: 'Rhenium' },
  76: { symbol: 'Os', name: 'Osmium' },
  77: { symbol: 'Ir', name: 'Iridium' },
  78: { symbol: 'Pt', name: 'Platinum' },
  79: { symbol: 'Au', name: 'Gold' },
  80: { symbol: 'Hg', name: 'Mercury' },
  81: { symbol: 'Tl', name: 'Thallium' },
  82: { symbol: 'Pb', name: 'Lead' },
  83: { symbol: 'Bi', name: 'Bismuth' },
  84: { symbol: 'Po', name: 'Polonium' },
  85: { symbol: 'At', name: 'Astatine' },
  86: { symbol: 'Rn', name: 'Radon' },
  87: { symbol: 'Fr', name: 'Francium' },
  88: { symbol: 'Ra', name: 'Radium' },
  89: { symbol: 'Ac', name: 'Actinium' },
  90: { symbol: 'Th', name: 'Thorium' },
  91: { symbol: 'Pa', name: 'Protactinium' },
  92: { symbol: 'U', name: 'Uranium' },
  93: { symbol: 'Np', name: 'Neptunium' },
  94: { symbol: 'Pu', name: 'Plutonium' },
  95: { symbol: 'Am', name: 'Americium' },
  96: { symbol: 'Cm', name: 'Curium' },
  97: { symbol: 'Bk', name: 'Berkelium' },
  98: { symbol: 'Cf', name: 'Californium' },
  99: { symbol: 'Es', name: 'Einsteinium' },
 100: { symbol: 'Fm', name: 'Fermium' },
 101: { symbol: 'Md', name: 'Mendelevium' },
 102: { symbol: 'No', name: 'Nobelium' },
 103: { symbol: 'Lr', name: 'Lawrencium' },
 104: { symbol: 'Rf', name: 'Rutherfordium' },
 105: { symbol: 'Db', name: 'Dubnium' },
 106: { symbol: 'Sg', name: 'Seaborgium' },
 107: { symbol: 'Bh', name: 'Bohrium' },
 108: { symbol: 'Hs', name: 'Hassium' },
 109: { symbol: 'Mt', name: 'Meitnerium' },
 110: { symbol: 'Ds', name: 'Darmstadtium' },
 111: { symbol: 'Rg', name: 'Roentgenium' },
 112: { symbol: 'Cn', name: 'Copernicium' },
 113: { symbol: 'Nh', name: 'Nihonium' },
 114: { symbol: 'Fl', name: 'Flerovium' },
 115: { symbol: 'Mc', name: 'Moscovium' },
 116: { symbol: 'Lv', name: 'Livermorium' },
 117: { symbol: 'Ts', name: 'Tennessine' },
 118: { symbol: 'Og', name: 'Oganesson' }
};

export function lookupElement(protons, neutrons, electrons) {
  const Z = Number(protons);
  const N = Number(neutrons);
  const e = Number(electrons);
  if (!Number.isInteger(Z) || Z < 0) return { found: false, text: 'Invalid proton count' };

  // special-cases for playful presets (Higgs / Hawking / Photon) detected by unusual fields or params
  // Caller can override behavior; here we handle only element/isotope lookup

  if (Z === 0) {
    // no protons — may be electron-only particle or vacuum
    if (N === 0 && e === 0) return { found: false, text: 'Vacuum / no particle' };
    if (e > 0 && N === 0) return { found: false, text: `${e} electron${e>1?'s':''} (no nucleus)` };
  }

  if (Z === 0 || Z > 118) return { found: false, text: 'Non-existent element' };

  const el = elements[Z];
  if (!el) return { found: true, name: `Element ${Z}`, symbol: `Z${Z}`, text: `Element Z=${Z}` };

  const A = Z + N;
  const charge = Z - e;
  const commonMass = el.commonMass;
  const isCommon = commonMass && commonMass === A;

  let isotopeNote = '';
  if (A <= 0) isotopeNote = 'invalid mass number';
  else if (isCommon) isotopeNote = `most common isotope A=${A}`;
  else isotopeNote = `isotope A=${A} (stability unknown)`;

  const ionNote = charge === 0 ? 'neutral' : (charge > 0 ? `ion +${charge}` : `ion ${charge}`);

  const text = `${el.name} (${el.symbol}) — ${isotopeNote} — ${ionNote}`;
  return { found: true, name: el.name, symbol: el.symbol, A, charge, text, isCommon: !!isCommon };
}

export default elements;
