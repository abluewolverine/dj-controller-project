// This file contains utility functions related to the simulation, such as generating synthetic data and performing calculations.

export const generateSyntheticData = (numSamples, parameters) => {
    const data = [];
    for (let i = 0; i < numSamples; i++) {
        const sample = {
            // Example of synthetic data generation logic
            value: Math.random() * parameters.scale,
            timestamp: new Date().toISOString(),
        };
        data.push(sample);
    }
    return data;
};

export const calculateStatistics = (data) => {
    const sum = data.reduce((acc, sample) => acc + sample.value, 0);
    const mean = sum / data.length;
    const variance = data.reduce((acc, sample) => acc + Math.pow(sample.value - mean, 2), 0) / data.length;
    const stdDev = Math.sqrt(variance);

    return {
        mean,
        variance,
        stdDev,
    };
};