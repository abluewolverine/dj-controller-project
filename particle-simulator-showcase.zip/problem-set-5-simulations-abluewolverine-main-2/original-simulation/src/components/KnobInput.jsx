import React, { useState, useRef } from 'react';

export default function KnobInput({ value, onChange, min = -Infinity, max = Infinity, step = 1, precision = 0, ariaLabel }) {
  const [editing, setEditing] = useState(false);
  const [pressed, setPressed] = useState(null); // 'up' | 'down' | null
  const inputRef = useRef(null);

  const clamp = (v) => Math.min(max, Math.max(min, v));

  const setVal = (v) => {
    const n = Number.isFinite(Number(v)) ? Number(v) : 0;
    const rounded = precision >= 0 ? Number(n.toFixed(precision)) : n;
    onChange(clamp(rounded));
  };

  const stepUp = () => setVal(Number(value ?? 0) + step);
  const stepDown = () => setVal(Number(value ?? 0) - step);

  const onDisplayClick = () => {
    setEditing(true);
    setTimeout(() => inputRef.current && inputRef.current.focus(), 0);
  };

  const onInputBlur = (e) => {
    const v = e.target.value;
    if (v === '') {
      onChange(null);
    } else {
      setVal(v);
    }
    setEditing(false);
  };

  const onInputKey = (e) => {
    if (e.key === 'Enter') {
      e.target.blur();
    } else if (e.key === 'Escape') {
      setEditing(false);
    }
  };

  return (
    <div className={`knob ${pressed ? 'knob-pressed' : ''}`} role="group" aria-label={ariaLabel}>
      <div className="knob-display" onClick={onDisplayClick} title="Click to type a value">
        {!editing ? (
          <div className="knob-value">{value === null || value === undefined ? '—' : String(value)}</div>
        ) : (
          <input
            ref={inputRef}
            className="knob-input-edit"
            defaultValue={value === null || value === undefined ? '' : value}
            onBlur={onInputBlur}
            onKeyDown={onInputKey}
          />
        )}
      </div>
      <div className="knob-buttons">
        <button
          className="knob-button up"
          onMouseDown={() => setPressed('up')}
          onMouseUp={() => setPressed(null)}
          onMouseLeave={() => setPressed(null)}
          onClick={stepUp}
          aria-label="increase"
        >
          ▲
        </button>
        <button
          className="knob-button down"
          onMouseDown={() => setPressed('down')}
          onMouseUp={() => setPressed(null)}
          onMouseLeave={() => setPressed(null)}
          onClick={stepDown}
          aria-label="decrease"
        >
          ▼
        </button>
      </div>
    </div>
  );
}
