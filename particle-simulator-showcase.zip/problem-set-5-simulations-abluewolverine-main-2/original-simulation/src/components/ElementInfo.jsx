import React from 'react';
import { lookupElement } from '../utils/elements';

export default function ElementInfo({ nProtons, nNeutrons, nElectrons }) {
  const info = lookupElement(nProtons, nNeutrons, nElectrons);

  if (!info) return null;
  if (!info.found) {
    return <div className="element-box"><strong>Lookup:</strong> <span className="small-muted">{info.text || 'Unknown'}</span></div>;
  }
  return (
    <div className="element-box">
      <div className="title">Lookup: {info.name} {info.symbol ? `(${info.symbol})` : ''}</div>
      <div className="meta">{info.text}</div>
    </div>
  );
}
