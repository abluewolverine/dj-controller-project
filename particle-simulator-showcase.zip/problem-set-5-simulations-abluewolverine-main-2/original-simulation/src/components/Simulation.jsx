import React from 'react';
import useSimulation from '../hooks/useSimulation';
import Controls from './Controls';
import SimulationView from './SimulationView';
import DevConsole from './DevConsole';
import '../styles/App.css';

const Simulation = () => {
    const { run, running, result } = useSimulation();

    return (
        <div className="container">
            <h2>Particle superposition simulator</h2>
            <div className="simulation-grid">
                <div>
                    <h1 className="panel-header">Element parameters</h1>
                    <Controls onRun={(opts) => run(opts)} running={running} simParams={result?.simParams} />
                </div>

                <div>
                    <SimulationView result={result} running={running} />
                </div>
            </div>
                    <div style={{ marginTop: 12 }}>
                        <DevConsole />
                    </div>
                </div>
    );
};

export default Simulation;