import React, { useEffect, useState, useRef } from 'react';
import { subscribeLogs, clearLogs, downloadLogs } from '../utils/devLog';

export default function DevConsole() {
  const [items, setItems] = useState([]);
  const ref = useRef(null);

  useEffect(() => {
    const unsub = subscribeLogs((logs) => setItems(logs));
    return unsub;
  }, []);

  useEffect(() => {
    // auto-scroll to bottom on new logs
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [items]);

  return (
  <div style={{ marginTop: 12, border: '1px dashed var(--card-border)', padding: 8, borderRadius: 6 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <strong>Developer console</strong>
        <div>
          <button className="button" onClick={() => { const data = downloadLogs(); const blob = new Blob([data], { type: 'application/json' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'dev-logs.json'; a.click(); URL.revokeObjectURL(url); }} style={{ marginRight: 8 }}>Download</button>
          <button className="button" onClick={() => clearLogs()}>Clear</button>
        </div>
      </div>
      <div ref={ref} style={{ maxHeight: 200, overflow: 'auto', fontFamily: 'monospace', fontSize: 12, marginTop: 8 }}>
        {items.length === 0 ? <div style={{ color: 'var(--muted)' }}>No logs yet</div> : items.map((it, idx) => (
          <div key={idx} style={{ padding: '2px 0', borderBottom: '1px solid var(--card-border)' }}>
            <div style={{ color: 'var(--muted)', opacity: 0.85 }}>{it.ts}</div>
            <div>{it.text}{it.meta && Object.keys(it.meta).length ? <span style={{ color: 'var(--muted)', opacity: 0.9 }}> — {JSON.stringify(it.meta)}</span> : null}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
