import React from 'react';

export default function ParamDisplay({ simParams }) {
  if (!simParams) return <div className="param-box">No derived parameters yet.</div>;
  const { mass, charge, stepVariance, bias, decoherence } = simParams;
  return (
    <div className="param-box">
      <h4>Derived simulation parameters</h4>
      <div>mass: {mass.toFixed(4)}</div>
      <div>charge: {charge.toFixed(4)}</div>
      <div>step variance: {stepVariance.toExponential(3)}</div>
      <div>bias: {bias.toFixed(4)}</div>
      <div>decoherence (0..1): {decoherence.toFixed(4)}</div>
    </div>
  );
}
