import React, { useMemo, useEffect, useRef, useState } from 'react';

// Lightweight SVG particle visualizer
// Props: result (simulation output), timeIndex, height, autoplay, fps
export default function ParticleViz({ result, timeIndex = null, height = 120, width = null, verticalStretch = 1.8, xScale = 1.0, autoplay = true, fps = 300 }) {
  const wave = result?.wavefield;
  // Memoize positions so the dependency in downstream useMemo is stable
  const positions = useMemo(() => {
    if (result?.positions) return result.positions;
    if (wave && wave.prob) return Array.from({ length: wave.prob[0].length }, (_, i) => i);
    return [];
  }, [result?.positions, wave]);

  const probs = useMemo(() => {
    if (!result) return [];
    if (wave && wave.prob) {
      const t = timeIndex == null ? wave.prob.length - 1 : Math.max(0, Math.min(wave.prob.length - 1, timeIndex));
      return Array.from(wave.prob[t]);
    }
    const pmf = result.pmf || {};
    return positions.map((p) => pmf[p] ?? pmf[String(p)] ?? 0);
  }, [result, timeIndex, wave, positions]);

  const L = Math.max(1, positions.length || probs.length);
  const maxP = Math.max(...probs, 0);
  const normalized = probs.map((v) => (maxP > 0 ? v / maxP : 0));
  const mean = result?.mean;

  // internal frame and bobbing
  const [internalIndex, setInternalIndex] = useState(timeIndex == null ? 0 : timeIndex);
  const phaseRef = useRef(0);
  const rafRef = useRef(null);

  useEffect(() => { if (timeIndex != null) setInternalIndex(timeIndex); }, [timeIndex]);

  useEffect(() => {
    if (!autoplay || !wave || !wave.prob) return;
    let last = performance.now();
    const T = wave.prob.length;
    function tick(now) {
      const dt = now - last;
      last = now;
      phaseRef.current += dt * 0.006;
      const frameMs = 1000 / Math.max(1, fps);
      const step = Math.floor(dt / frameMs);
      if (step > 0) setInternalIndex((idx) => (T > 0 ? (idx + step) % T : idx));
      rafRef.current = requestAnimationFrame(tick);
    }
    rafRef.current = requestAnimationFrame(tick);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); rafRef.current = null; };
  }, [autoplay, wave, fps]);

  const phase = phaseRef.current;

  // layout constants
  const rows = 8;
  // horizontal margins inside the logical viewBox — shrink these to use more horizontal space
  const baseLeft = 2;
  const baseRight = 98;
  const baseSpan = baseRight - baseLeft;
  const center = (baseLeft + baseRight) / 2;
  // apply xScale relative to center so positions expand/contract symmetrically
  // allow a much larger scaled span so high xScale values can spread positions wider
  const scaledSpan = Math.max(8, Math.min(400, baseSpan * xScale));
  const xLeft = center - scaledSpan / 2;
  const xRight = center + scaledSpan / 2;
  const xSpan = xRight - xLeft;
  // verticalScale amplifies the vertical spacing inside the SVG so the scene itself is less compressed
  // verticalStretch lets callers exaggerate the vertical spacing to reduce perceived compression
  const verticalScale = Math.min(3.0, Math.max(1.0, (height / 84) * verticalStretch));
  // place front plane lower and increase layer offset so the scene is taller (less vertically compressed)
  const frontY = Math.max(36, height * 0.82);
  const layerYOffset = Math.max(8, Math.min(26, height * 0.09));

  // allow explicit pixel width or fall back to fluid 100% width from the parent
  const wrapperStyle = { width: width ? `${width}px` : '100%', height, padding: 0, boxSizing: 'border-box' };
  const svgStyle = { width: width ? `${width}px` : '100%', height: `${height}px`, display: 'block' };

  return (
    <div style={wrapperStyle} className="particle-viz">
  {/* use 'meet' preserveAspectRatio to avoid cropping/zoom — we want to spread the x-axis logically, not zoom the view */}
  <svg viewBox={`0 0 100 ${height}`} preserveAspectRatio="xMidYMid meet" style={svgStyle}>
        <defs>
          {/* metallic teal gradient: bright specular -> mint -> deep teal */}
          <radialGradient id="pv-grad" cx="35%" cy="28%" r="72%">
            {/* center warm maize -> mid maize -> deep blue rim for a maize-gold sphere with blue edge */}
            <stop offset="0%" stopColor="var(--um-maize)" stopOpacity="0.98" />
            <stop offset="28%" stopColor="#ffe57f" stopOpacity="0.96" />
            <stop offset="62%" stopColor="var(--um-maize)" stopOpacity="0.9" />
            <stop offset="92%" stopColor="var(--um-blue)" stopOpacity="1" />
            <stop offset="100%" stopColor="var(--um-blue-dark)" stopOpacity="1" />
          </radialGradient>
          <filter id="pv-shadow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#000" floodOpacity="0.22" />
          </filter>

          <pattern id="prob-pattern" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(25)">
            <rect width="6" height="6" fill="var(--card)" />
            <path d="M0 0 L0 1" stroke="var(--um-blue)" strokeOpacity="0.08" strokeWidth="0.7" />
            <path d="M3 0 L3 1" stroke="var(--um-blue)" strokeOpacity="0.06" strokeWidth="0.5" />
          </pattern>

          <marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M 0 0 L 10 5 L 0 10 z" fill="var(--muted)" />
          </marker>
        </defs>

        {/* grid rows */}
        {Array.from({ length: rows }).map((_, r) => {
          const depth = r / Math.max(1, rows - 1);
          // amplify the vertical spacing for deeper rows using verticalScale
          const y = frontY - depth * (layerYOffset * 3 + 6) * verticalScale;
          const rowScale = 1 - depth * 0.5;
          return (
            <g key={`row-${r}`} opacity={0.82 - depth * 0.5}>
              {Array.from({ length: L }).map((_, i) => {
                const xRaw = xLeft + (i / Math.max(1, L - 1)) * xSpan;
                const shift = (center - xRaw) * (depth * 0.25);
                const x = xRaw + shift;
                const dotR = 0.9 * rowScale;
                return <circle key={`${r}-${i}`} cx={x} cy={y} r={dotR} fill="var(--um-blue)" opacity={0.18} />;
              })}
            </g>
          );
        })}

        {/* grid lines */}
        {Array.from({ length: rows }).map((_, r) => {
          const depth = r / Math.max(1, rows - 1);
          const y = frontY - depth * (layerYOffset * 3 + 6) * verticalScale;
          return <line key={`grid-${r}`} x1={xLeft + 6} y1={y} x2={xRight - 6} y2={y} stroke="var(--um-blue)" opacity={0.08} strokeWidth={0.6} />;
        })}

        {/* axes */}
        {(() => {
          const originX = xLeft + 6;
          const originY = frontY + 2;
          const xEnd = xRight - 6;
          const yEnd = Math.max(6, originY - 26);
          const zEndX = originX + 34;
          const zEndY = originY - 20;
          return (
            <g stroke="var(--muted)" strokeWidth={0.9} fill="none" opacity={0.95}>
              <line x1={originX} y1={originY} x2={xEnd} y2={originY} markerEnd="url(#arrow)" />
              <line x1={originX} y1={originY} x2={originX} y2={yEnd} markerEnd="url(#arrow)" />
              <line x1={originX} y1={originY} x2={zEndX} y2={zEndY} markerEnd="url(#arrow)" />
              <text x={xEnd - 6} y={originY + 8} fontSize={6} fill="var(--muted)">X</text>
              <text x={originX - 8} y={yEnd - 4} fontSize={6} fill="var(--muted)">Y</text>
              <text x={zEndX + 2} y={zEndY - 2} fontSize={6} fill="var(--muted)">Z</text>
            </g>
          );
        })()}

        {/* textured probability bars on front plane */}
        {(() => {
          const spacing = L > 1 ? xSpan / (L - 1) : xSpan;
          // allow taller bars so texture and projection read better with increased height; scale with verticalScale
          const bandMax = Math.min(80, height * 0.8) * verticalScale;
          return (
            <g>
              {normalized.map((nv, i) => {
                const xRaw = xLeft + (i / Math.max(1, L - 1)) * xSpan;
                const x = xRaw - spacing * 0.5;
                const w = Math.max(2.4, spacing * 0.85);
                const h = nv * bandMax;
                const y = frontY - h;
                const opacity = 0.18 + 0.82 * nv;
                return (
                  <rect key={`prob-${i}`} x={x} y={y} width={w} height={h} fill="url(#prob-pattern)" opacity={opacity} stroke="var(--um-blue)" strokeWidth={0.28} rx={1} />
                );
              })}
              <path d={(() => {
                if (L === 0) return '';
                const pts = normalized.map((nv, i) => {
                  const xRaw = xLeft + (i / Math.max(1, L - 1)) * xSpan;
                  const h = nv * bandMax;
                  const y = frontY - h;
                  return `${xRaw},${y}`;
                });
                return `M ${pts[0]} L ${pts.slice(1).join(' L ')} L ${xRight},${frontY} L ${xLeft},${frontY} Z`;
              })()} fill="none" stroke="var(--um-blue)" strokeWidth={0.8} opacity={0.85} />
            </g>
          );
        })()}

        {/* render a field (cloud) of possible particle locations weighted by probability, plus highlighted mean */}
        {(() => {
          if (L === 0) return null;
          // deterministic pseudo-random generator based on seed
          const rand = (s) => {
            const x = Math.sin(s) * 43758.5453123;
            return x - Math.floor(x);
          };
          const spacing = L > 1 ? xSpan / (L - 1) : xSpan;
          const cloud = [];

          // build dots per position proportional to probability
          normalized.forEach((nv, i) => {
            const xRaw = xLeft + (i / Math.max(1, L - 1)) * xSpan;
            const h = Math.min(40, height * 0.6) * nv; // vertical extent for dots
            const count = Math.max(3, Math.round(1 + nv * 12));
            for (let k = 0; k < count; k++) {
              const seed = i * 131 + k * 37 + (internalIndex || 0) * 17;
              const rx = (rand(seed) - 0.5) * spacing * 0.6;
              const ry = Math.pow(rand(seed + 1), 0.8) * h * verticalScale; // amplify vertical jitter
              const depthRand = rand(seed + 2);
              const depthLayer = Math.floor(depthRand * rows);
              const yLayer = frontY - (depthLayer / Math.max(1, rows - 1)) * (layerYOffset * 3 + 6) * verticalScale;
              const y = yLayer - ry - Math.sin(phase + seed) * (2 * verticalScale);
              const cx = xRaw + rx + (center - xRaw) * ((depthLayer / Math.max(1, rows - 1)) * 0.25);
              const r = (0.6 + 1.8 * nv * (0.6 + 0.4 * rand(seed + 3))) * Math.sqrt(verticalScale);
              const opacity = 0.05 + 0.9 * nv * (0.6 + 0.4 * rand(seed + 4));
              cloud.push({ cx, cy: y, r, opacity });
            }
          });

          return (
            <g>
              {/* draw cloud dots (back-to-front) */}
              {cloud.map((d, idx) => (
                <circle key={`dot-${idx}`} cx={d.cx} cy={d.cy} r={d.r} fill="var(--um-blue)" opacity={d.opacity} />
              ))}

              {/* highlighted mean marker on top for orientation */}
              {typeof mean === 'number' && !Number.isNaN(mean) ? (() => {
                const m = Math.max(0, Math.min(L - 1, mean));
                const mxRaw = xLeft + (m / Math.max(1, L - 1)) * xSpan;
                const pAtMean = normalized[Math.round(m)] || 0;
                // increase height offset mapping so the sphere floats higher above the plane; scale with verticalScale
                const heightOffset = (8 + 36 * Math.sqrt(pAtMean)) * verticalScale;
                const zLayer = Math.max(0, Math.min(rows - 1, Math.round((1 - pAtMean) * (rows - 1))));
                const zY = frontY - (zLayer / Math.max(1, rows - 1)) * (layerYOffset * 3 + 6);
                const center = 50;
                const shift = (center - mxRaw) * ((zLayer / Math.max(1, rows - 1)) * 0.25);
                const mx = mxRaw + shift;
                const cy = zY - heightOffset - Math.sin(phase) * (4 * verticalScale);
                const size = (8 + 20 * Math.sqrt(pAtMean)) * Math.sqrt(verticalScale);
                const shadowRx = size * (0.9 + 0.6 * pAtMean) * Math.sqrt(verticalScale);
                const shadowRy = size * 0.22;
                return (
                  <g>
                    <line x1={mx} y1={cy + size * 0.2} x2={mx} y2={frontY} stroke="var(--um-blue)" strokeWidth={0.8} strokeDasharray="2 2" opacity={0.28} />
                    <ellipse cx={mx} cy={frontY + 6} rx={shadowRx} ry={shadowRy} fill="#000" opacity={0.12} />
                    <g transform={`translate(${mx}, ${cy})`}>
                      <g filter="url(#pv-shadow)">
                        <circle r={size} cx={0} cy={0} fill={`url(#pv-grad)`} />
                      </g>
                      {/* brighter specular */}
                      <ellipse cx={-size * 0.26} cy={-size * 0.34} rx={size * 0.36} ry={size * 0.16} fill="var(--card)" opacity={0.88} />
                    </g>
                  </g>
                );
              })() : null}
            </g>
          );
        })()}
      </svg>
    </div>
  );
}
