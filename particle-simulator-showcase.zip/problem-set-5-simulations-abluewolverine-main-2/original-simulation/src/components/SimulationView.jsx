import React, { useEffect, useRef, useState } from 'react';
import ParticleViz from './ParticleViz';
import { lookupElement } from '../utils/elements';

function compactEntries(pmf) {
  if (!pmf) return [];
  return Object.keys(pmf)
    .map((k) => ({ x: Number(k), p: pmf[k] }))
    .sort((a, b) => a.x - b.x);
}

function probabilityToColor(v, vmax) {
  // simple grayscale mapping (v in [0, vmax])
  const norm = vmax <= 0 ? 0 : Math.max(0, Math.min(1, v / vmax));
  const c = Math.floor(255 * norm);
  return [c, c, c, 255];
}

function signedToColor(v, vmax) {
  // blue-white-red mapping for signed values centered at 0
  const norm = vmax <= 0 ? 0 : Math.max(-1, Math.min(1, v / vmax));
  const r = Math.floor(127.5 * (1 + norm));
  const b = Math.floor(127.5 * (1 - norm));
  const g = 200 - Math.floor(80 * Math.abs(norm));
  return [r, g, b, 255];
}

function phaseToColor(phase) {
  // map phase [-pi, pi] to hue
  const p = (phase + Math.PI) / (2 * Math.PI); // 0..1
  const h = p * 360;
  // simple HSV->RGB
  const x = 1 - Math.abs(((h / 60) % 2) - 1);
  let r = 0, g = 0, b = 0;
  if (h < 60) [r, g, b] = [1, x, 0];
  else if (h < 120) [r, g, b] = [x, 1, 0];
  else if (h < 180) [r, g, b] = [0, 1, x];
  else if (h < 240) [r, g, b] = [0, x, 1];
  else if (h < 300) [r, g, b] = [x, 0, 1];
  else [r, g, b] = [1, 0, x];
  return [Math.floor(255 * r), Math.floor(255 * g), Math.floor(255 * b), 255];
}

export default function SimulationView({ result, running }) {
  const canvasRef = useRef(null);
  const [field, setField] = useState('prob');
  const [plotField, setPlotField] = useState('pmf');
  const [timeIndex, setTimeIndex] = useState(null);
  const plotRef = useRef(null);
  // right column refs + adaptive padding so content lines up with heatmap
  const rightColRef = useRef(null);
  const [rightPad, setRightPad] = useState(120);
  const tableRef = useRef(null);
  const simpleRef = useRef(null);
  const conclRef = useRef(null);
  const [conclMax, setConclMax] = useState(576);
  // default xScale to the slider maximum so positions start fully spread
  const [xScale, setXScale] = useState(4.0);
  const [autoOscillate, setAutoOscillate] = useState(true);
  const lastUserRef = useRef(0);
  const oscRafRef = useRef(null);
  const [oscPeriodSec, setOscPeriodSec] = useState(8.0); // default period in seconds (full back-and-forth)

  useEffect(() => {
    if (!result || result.error) return;
    const wave = result.wavefield;
    if (!wave) return;

    const probSeries = wave.prob; // array of Float32Array rows (t x x)
    const reSeries = wave.re;
    const imSeries = wave.im;
    const T = probSeries.length; // rows
    const L = probSeries[0].length; // cols

    const canvas = canvasRef.current;
    if (!canvas) return;
    // limit canvas size for performance but keep aspect
    const maxWidth = 700;
    const maxHeight = 500;
    const pixelW = Math.min(2, Math.max(1, Math.floor(maxWidth / L)));
    const pixelH = Math.min(3, Math.max(1, Math.floor(maxHeight / T)));
    const width = L * pixelW;
    const height = T * pixelH;
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    const img = ctx.createImageData(width, height);

    // compute vmax for scaling
    let vmax = 0;
    if (field === 'prob') {
      for (let t = 0; t < T; t++) {
        for (let x = 0; x < L; x++) {
          vmax = Math.max(vmax, probSeries[t][x]);
        }
      }
    } else if (field === 'real' || field === 'imag') {
      for (let t = 0; t < T; t++) {
        for (let x = 0; x < L; x++) {
          const v = field === 'real' ? reSeries[t][x] : imSeries[t][x];
          vmax = Math.max(vmax, Math.abs(v));
        }
      }
    }

    // fill pixels: for each row t, col x map to block of pixels
    for (let t = 0; t < T; t++) {
      for (let x = 0; x < L; x++) {
        let color = [0, 0, 0, 255];
        if (field === 'prob') {
          color = probabilityToColor(probSeries[t][x], vmax);
        } else if (field === 'real') {
          color = signedToColor(reSeries[t][x], vmax || 1);
        } else if (field === 'imag') {
          color = signedToColor(imSeries[t][x], vmax || 1);
        } else if (field === 'phase') {
          const re = reSeries[t][x];
          const im = imSeries[t][x];
          const phase = Math.atan2(im, re);
          color = phaseToColor(phase);
        }
        // draw pixel block
        for (let py = 0; py < pixelH; py++) {
          for (let px = 0; px < pixelW; px++) {
            const cx = x * pixelW + px;
            const cy = t * pixelH + py;
            const idx = (cy * width + cx) * 4;
            img.data[idx] = color[0];
            img.data[idx + 1] = color[1];
            img.data[idx + 2] = color[2];
            img.data[idx + 3] = color[3];
          }
        }
      }
    }

    ctx.putImageData(img, 0, 0);
    // update timeIndex default to final timestep when new result arrives
    if (result.wavefield && timeIndex === null) {
      setTimeIndex(result.wavefield.prob.length - 1);
    }

    // measure and set right-column padding so boxes align next to the heatmap
    try {
      const canvasEl = canvasRef.current;
      const rightEl = rightColRef.current;
      if (canvasEl && rightEl) {
        // canvas clientHeight reflects layout size; fall back to canvas.height
        const ch = canvasEl.clientHeight || canvasEl.height || 0;
        // measure top blocks inside right column
        const tableH = (tableRef.current && (tableRef.current.scrollHeight || tableRef.current.offsetHeight)) || 0;
        const simpleH = (simpleRef.current && (simpleRef.current.scrollHeight || simpleRef.current.offsetHeight)) || 0;
        const groupH = rightEl.scrollHeight || rightEl.offsetHeight || (tableH + simpleH);
        // center the right content vertically beside the canvas
        const pad = Math.max(8, Math.floor((ch - groupH) / 2));
        setRightPad(pad);
  // compute a max-height for conclusions so it doesn't extend past canvas bottom
  // allow a larger minimum and reduce the subtraction margin so conclusions can be taller
  const available = Math.max(216, ch - pad - tableH - simpleH - 8);
  setConclMax(available);
      }
    } catch (err) {
      // ignore measurement errors
    }
  }, [result, field]);

  // recompute on window resize to keep alignment responsive
  useEffect(() => {
    function onResize() {
      const canvasEl = canvasRef.current;
      const rightEl = rightColRef.current;
      if (canvasEl && rightEl) {
        const ch = canvasEl.clientHeight || canvasEl.height || 0;
        const tableH = (tableRef.current && (tableRef.current.scrollHeight || tableRef.current.offsetHeight)) || 0;
        const simpleH = (simpleRef.current && (simpleRef.current.scrollHeight || simpleRef.current.offsetHeight)) || 0;
        const groupH = rightEl.scrollHeight || rightEl.offsetHeight || (tableH + simpleH);
        const pad = Math.max(8, Math.floor((ch - groupH) / 2));
        setRightPad(pad);
  const available = Math.max(216, ch - pad - tableH - simpleH - 8);
  setConclMax(available);
      }
    }
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  // effect: update the small line plot when result / plotField / timeIndex change
  useEffect(() => {
    if (!plotRef || !plotRef.current) return;
    if (!result) return;

    const wave = result.wavefield;
    const positions = result.positions || (wave && wave.prob ? Array.from({ length: wave.prob[0].length }, (_, i) => i) : []);
    let t = timeIndex;
    if (t === null) t = wave && wave.prob ? wave.prob.length - 1 : 0;

    let dataY = null;
    if (plotField === 'pmf') {
      if (wave && wave.prob && wave.prob[t]) dataY = Array.from(wave.prob[t]);
      else if (result.pmf) {
        // convert pmf object to ordered array matching positions
        dataY = positions.map((pos) => {
          const key = typeof pos === 'number' ? String(pos) : pos;
          return (result.pmf && (result.pmf[pos] !== undefined || result.pmf[key] !== undefined)) ? (result.pmf[pos] ?? result.pmf[key]) : 0;
        });
      } else dataY = [];
    } else if (plotField === 'real') {
      if (wave && wave.re && wave.re[t]) dataY = Array.from(wave.re[t]); else dataY = [];
    } else if (plotField === 'imag') {
      if (wave && wave.im && wave.im[t]) dataY = Array.from(wave.im[t]); else dataY = [];
    }

    // draw (guard for empty data)
    try {
      drawLinePlot(plotRef.current, positions, dataY);
    } catch (err) {
      // fail silently but log to console for debugging
      // console.error('drawLinePlot error', err);
    }
  }, [result, plotField, timeIndex]);

  // auto-oscillate the timeIndex (sine/back-and-forth) while allowing manual slider control.
  // If the user interacts with the slider, pause auto updates briefly so the UI doesn't fight the user.
  useEffect(() => {
    if (!result || !result.wavefield) return;
    const Tsteps = result.wavefield.prob.length;
    if (!autoOscillate || Tsteps <= 1) return undefined;
    let start = performance.now();
  const PERIOD_MS = Math.max(500, Math.min(60000, Math.round(oscPeriodSec * 1000))); // full back-and-forth cycle (ms)
    function tick(now) {
      const elapsed = now - start;
      const phase = ((elapsed % PERIOD_MS) / PERIOD_MS) * Math.PI * 2; // 0..2π
  // sinusoidal mapping to [0,1], then to time index 0..T-1
      const frac = 0.5 + 0.5 * Math.sin(phase);
      const idx = Math.round(frac * (Tsteps - 1));
      // skip auto update if user interacted recently (2.2s)
      try {
        if (Date.now() - (lastUserRef.current || 0) > 2200) {
          setTimeIndex(idx);
        }
      } catch (err) {
        // ignore
      }
      oscRafRef.current = requestAnimationFrame(tick);
    }
    oscRafRef.current = requestAnimationFrame(tick);
    return () => { if (oscRafRef.current) cancelAnimationFrame(oscRafRef.current); oscRafRef.current = null; };
  }, [result, autoOscillate, oscPeriodSec]);

  // compute probability conservation stats
  let conservation = null;
  if (result && result.wavefield && result.wavefield.prob) {
    const probSeries = result.wavefield.prob;
    const sums = probSeries.map((row) => {
      let s = 0;
      for (let i = 0; i < row.length; i++) s += row[i];
      return s;
    });
    const min = Math.min(...sums);
    const max = Math.max(...sums);
    const mean = sums.reduce((a, b) => a + b, 0) / sums.length;
    conservation = { min, max, mean };
  }

  // safe derived rendering values (allow rendering placeholder without throwing)
  if (result && result.error) return <div style={{ padding: 8, color: 'red' }}>Error: {result.error}</div>;
  const mode = result?.mode ?? 'no-data';
  const T = result?.T ?? (result?.wavefield ? result.wavefield.prob.length : 0);
  const pmf = result?.pmf ?? {};
  const mean = result?.mean;
  const variance = result?.variance;
  const entries = compactEntries(pmf);

  function generateConclusions() {
    if (result && result.error) return ['Error: no conclusions available.'];
    const lines = [];
    // basic summary
    lines.push(`Mode: ${mode}.`);
    // conservation note
    if (conservation) {
      const dev = Math.abs(conservation.mean - 1);
      if (dev < 1e-3) lines.push('Total probability is conserved across time (numerically stable).');
      else if (dev < 1e-2) lines.push('Total probability roughly conserved (small numerical drift).');
      else lines.push('Warning: total probability not conserved — results may be numerically inaccurate.');
    }

    // localization and predictability
    if (pmf) {
      const peak = entries.reduce((a, b) => (b.p > a.p ? b : a), { x: 0, p: 0 });
      if (peak.p > 0.35) {
        lines.push(`The particle is fairly localized: position ${peak.x} has high probability (${(peak.p * 100).toFixed(1)}%).`);
      } else if (peak.p > 0.15) {
        lines.push(`The particle shows moderate localization around ${peak.x} (peak ${(peak.p * 100).toFixed(1)}%).`);
      } else {
        lines.push('The particle is broadly distributed across positions (low predictability).');
      }
      // variance comment
      if (variance < 4) lines.push('Low variance indicates the particle remains near the origin over time.');
      else if (variance < 50) lines.push('Moderate variance indicates some spreading from the initial position.');
      else lines.push('High variance indicates the particle distribution spreads widely over time.');
    }

    // quantum-specific notes
    if (mode === 'quantum') {
      const deco = result.simParams?.decoherence ?? 0;
      if (deco < 0.05) lines.push('Low decoherence: expect clear quantum interference patterns (phase effects).');
      else if (deco < 0.3) lines.push('Moderate decoherence: interference partially suppressed; distribution is between quantum and classical.');
      else lines.push('High decoherence: interference suppressed; behavior resembles a classical random walk.');
    }

    lines.push('Interpretation guidance: probability (|ψ|²) gives likelihood of finding the particle at a position. Bright regions in the heatmap indicate higher likelihood.');
    return lines;
  }

  function generateSimpleInterpretation() {
    // one-line simple interpretation for non-experts
    if (!pmf || entries.length === 0) return 'No data to interpret.';
    const peak = entries.reduce((a, b) => (b.p > a.p ? b : a), { x: 0, p: 0 });
    if (peak.p > 0.35) return `Simple: the particle is likely to be at position ${peak.x} (high probability).`;
    if (peak.p > 0.15) return `Simple: the particle shows a moderate chance of being near ${peak.x}.`;
    return 'Simple: the particle is broadly spread — it is not concentrated at a specific position at a given time.';
  }

  

  // lookup element name if counts are present in result
  const elemInfo = result ? lookupElement(result.nProtons ?? 0, result.nNeutrons ?? 0, result.nElectrons ?? 0) : null;

  return (
    <div className={`simulation-result ${result ? 'has-result' : 'placeholder'}`}>
      {!result ? (
        <div className="placeholder-inner">Run the simulation to see results.</div>
      ) : (
        <div className="result-inner">
          <h3>
            {mode} result
            {elemInfo && elemInfo.found ? (
              <span style={{ marginLeft: 8, fontWeight: 600, fontSize: '0.95em', color: 'var(--muted)' }}>{elemInfo.name}{elemInfo.symbol ? ` (${elemInfo.symbol})` : ''}</span>
            ) : null}
            <span style={{ marginLeft: 8, color: 'var(--muted)', fontSize: '0.95em' }}>(T={T})</span>
          </h3>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            <div>mean ≈ {mean?.toFixed(4)} | variance ≈ {variance?.toFixed(4)}</div>
            {conservation && (
              <div style={{ marginLeft: 12 }}>
                <strong>Probability conservation</strong>
                <div>mean: {conservation.mean.toFixed(6)}</div>
                <div>min: {conservation.min.toFixed(6)} | max: {conservation.max.toFixed(6)}</div>
                <div style={{ marginTop: 4 }}>
                  <span style={{ display: 'inline-block', width: 12, height: 12, borderRadius: 3, background: (Math.abs(conservation.mean - 1) < 1e-3) ? 'limegreen' : (Math.abs(conservation.mean - 1) < 1e-2 ? 'orange' : 'red') }} />
                  <span style={{ marginLeft: 8, fontSize: 12 }}>{Math.abs(conservation.mean - 1) < 1e-3 ? 'OK' : Math.abs(conservation.mean - 1) < 1e-2 ? 'Warning' : 'Bad'}</span>
                </div>
              </div>
            )}
          </div>
          <div style={{ display: 'flex', gap: 12, marginTop: 8 }}>
            <div style={{ flex: 1 }}>
                {/* Line plot / distribution moved above the field */}
                <div style={{ marginBottom: 10 }}>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <label style={{ minWidth: 44 }}>Plot: </label>
                    <select value={plotField} onChange={(e) => setPlotField(e.target.value)}>
                      <option value="pmf">PMF (|ψ|²)</option>
                      <option value="real">Real(ψ)</option>
                      <option value="imag">Imag(ψ)</option>
                    </select>
                    <label style={{ marginLeft: 12 }}>X scale:</label>
                    <input type="range" min={0.5} max={4.0} step={0.1} value={xScale} onChange={(e) => setXScale(Number(e.target.value))} style={{ width: 140 }} />
                    <div style={{ width: 40, textAlign: 'right' }}>{xScale.toFixed(1)}x</div>
                    <label style={{ marginLeft: 12 }}>Time step:</label>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1 }}>
                      <input
                        type="range"
                        min={0}
                        max={(result.wavefield ? result.wavefield.prob.length - 1 : 0)}
                        value={timeIndex ?? (result.wavefield ? result.wavefield.prob.length - 1 : 0)}
                        onChange={(e) => {
                          const v = Number(e.target.value);
                          setTimeIndex(v);
                          // record user interaction time so auto-oscillator can pause briefly
                          try { lastUserRef.current = Date.now(); } catch (err) {}
                        }}
                        style={{ flex: 1 }}
                      />
                      <div style={{ width: 48, textAlign: 'right' }}>{timeIndex ?? (result.wavefield ? result.wavefield.prob.length - 1 : 0)}</div>
                      <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginLeft: 6 }}>
                        <div style={{ fontSize: 12, color: 'var(--muted)', minWidth: 40, textAlign: 'right' }}>{oscPeriodSec.toFixed(1)}s</div>
                        <input type="range" min={2} max={60} step={0.5} value={oscPeriodSec} onChange={(e) => setOscPeriodSec(Number(e.target.value))} style={{ width: 120 }} aria-label="Oscillation period (s)" />
                        <button
                          title={autoOscillate ? 'Auto-oscillate: ON (click to turn off)' : 'Auto-oscillate: OFF (click to turn on)'}
                          onClick={() => { setAutoOscillate((s) => !s); try { lastUserRef.current = Date.now(); } catch (err) {} }}
                          style={{ padding: '6px 8px', fontSize: 12 }}
                        >
                          {autoOscillate ? 'Auto ⟳' : 'Auto ⟲'}
                        </button>
                      </div>
                    </div>
                  </div>
                  <canvas ref={plotRef} className="plot-canvas" style={{ width: '100%', marginTop: 8 }} />
                  <div style={{ marginTop: 8, display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                    {/* enlarge the 3D particle viz: give the container a fixed width so the SVG has room */}
                    {/* let ParticleViz grow to fill available space */}
                    <div style={{ flex: '1 1 0', boxSizing: 'border-box', minWidth: 320 }}>
                      <ParticleViz result={result} timeIndex={timeIndex} height={420} verticalStretch={2.6} xScale={xScale} autoplay={true} fps={8} />
                    </div>
                    {/* Legend / key placed to the right of the 3D viz */}
                    <div style={{ width: 220, display: 'flex', flexDirection: 'column', gap: 8 }}>
                      <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                        <svg width="28" height="28" viewBox="0 0 28 28"><circle cx="14" cy="11" r="8" fill="var(--um-maize)" /></svg>
                        <div>
                          <strong>Mean (sphere)</strong>
                          <div style={{ color: 'var(--muted)', fontSize: 12 }}>Sphere = ⟨x⟩; size & height ∝ local probability (|ψ|²)</div>
                        </div>
                      </div>

                      <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                        <svg width="36" height="28" viewBox="0 0 36 28">
                          <g fill="var(--um-blue)" opacity="0.85">
                            <circle cx="6" cy="18" r="1.4" />
                            <circle cx="11" cy="14" r="1.6" />
                            <circle cx="16" cy="19" r="1.3" />
                            <circle cx="22" cy="12" r="1.5" />
                            <circle cx="28" cy="16" r="1.1" />
                          </g>
                        </svg>
                        <div>
                          <strong>Possible locations (cloud)</strong>
                          <div style={{ color: 'var(--muted)', fontSize: 12 }}>Cloud density & opacity ∝ probability; dots animate over time</div>
                        </div>
                      </div>

                      <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                        <svg width="36" height="28" viewBox="0 0 36 28">
                          <rect x="1" y="6" width="6" height="14" fill="var(--card)" stroke="var(--um-blue)" />
                          <rect x="10" y="4" width="6" height="16" fill="var(--card)" stroke="var(--um-blue)" />
                          <rect x="19" y="8" width="6" height="12" fill="var(--card)" stroke="var(--um-blue)" />
                        </svg>
                        <div>
                          <strong>Projection (bars)</strong>
                          <div style={{ color: 'var(--muted)', fontSize: 12 }}>Textured bars show per-position PMF projected onto the front plane</div>
                        </div>
                      </div>

                      <div style={{ marginTop: 6, fontSize: 12, color: 'var(--muted)' }}>
                        <em>Tip:</em> Use the time slider above to step through frames; autoplay advances the wave over time.
                      </div>
                    </div>
                  </div>
                </div>

                <div style={{ marginBottom: 6 }}>
                  <label>Field: </label>
                  <select value={field} onChange={(e) => setField(e.target.value)}>
                    <option value="prob">Probability |ψ|²</option>
                    <option value="real">Real(ψ)</option>
                    <option value="imag">Imag(ψ)</option>
                    <option value="phase">Phase(ψ)</option>
                  </select>
                </div>
                <canvas ref={canvasRef} className="heatmap-canvas" style={{ width: '100%', border: '1px solid var(--card-border)' }} />
              {/* X-axis ticks / labels */}
              <div style={{ position: 'relative', height: 28, marginTop: 6 }}>
                {(() => {
                  // compute positions and canvas width to position ticks
                  const positions = result.positions || entries.map((e) => e.x);
                  const L = positions.length;
                  const ticks = [];
                  const nTicks = 5;
                  for (let i = 0; i < nTicks; i++) {
                    const idx = Math.round((i / (nTicks - 1)) * (L - 1));
                    ticks.push({ idx, x: positions[idx] });
                  }
                  return ticks.map((t, i) => (
                    <div key={i} style={{ position: 'absolute', left: `${(t.idx / Math.max(1, L - 1)) * 100}%`, transform: 'translateX(-50%)', fontSize: 12 }}>
                      {t.x}
                    </div>
                  ));
                })()}
                <div style={{ position: 'absolute', left: 0, right: 0, textAlign: 'center', top: 18, fontSize: 12, color: 'var(--muted)' }}>position (0 = center)</div>
              </div>
            </div>
            <div ref={rightColRef} style={{ width: 180, paddingTop: rightPad, display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div ref={tableRef} style={{ maxHeight: 300, overflow: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr>
                      <th style={{ textAlign: 'left' }}>x</th>
                      <th style={{ textAlign: 'left' }}>p(x)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {entries.map((e) => (
                      <tr key={e.x}>
                        <td style={{ padding: '2px 6px' }}>{e.x}</td>
                        <td style={{ padding: '2px 6px' }}>{e.p.toExponential(3)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div ref={simpleRef} style={{ marginBottom: 8 }}>
                <div style={{ border: '1px solid var(--card-border)', padding: 8, borderRadius: 4, background: 'var(--card)' }}>
                  <strong>Simple interpretation</strong>
                  <div style={{ marginTop: 6 }}>{generateSimpleInterpretation()}</div>
                </div>
              </div>
              <div ref={conclRef} style={{ marginTop: 8, border: '1px solid var(--card-border)', padding: 10, borderRadius: 6, background: 'var(--card)', maxHeight: conclMax, overflow: 'auto' }}>
                <h4 style={{ margin: '0 0 8px 0' }}>Scientific interpretation</h4>
                {generateConclusions().map((line, i) => (
                  <div key={i} style={{ marginBottom: 6, fontSize: 13 }}>{line}</div>
                ))}
              </div>
            </div>
          </div>

          {/* (Scientific interpretation moved into right column) */}
        </div>
      )}
    </div>
  );
}

// draw the line plot for PMF / Real / Imag
function drawLinePlot(canvas, dataX, dataY) {
  if (!canvas || !dataY) return;
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const styleW = canvas.clientWidth;
  const styleH = canvas.clientHeight;
  canvas.width = Math.max(300, styleW * dpr);
  canvas.height = Math.max(120, styleH * dpr);
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, styleW, styleH);
  // margins
  const m = { left: 40, right: 16, top: 8, bottom: 24 };
  const w = styleW - m.left - m.right;
  const h = styleH - m.top - m.bottom;
  // x scale
  const n = dataY.length;
  const xmin = 0, xmax = n - 1;
  const ymin = Math.min(...dataY);
  const ymax = Math.max(...dataY);
  const pad = (ymax - ymin) * 0.05 || 1e-6;
  const y0 = ymin - pad, y1 = ymax + pad;
  const xToPx = (i) => m.left + (i - xmin) / (xmax - xmin) * w;
  const yToPx = (v) => m.top + h - (v - y0) / (y1 - y0) * h;
  // axes
  ctx.strokeStyle = '#4a5563'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(m.left, m.top); ctx.lineTo(m.left, m.top + h); ctx.lineTo(m.left + w, m.top + h); ctx.stroke();
  // y ticks
  ctx.fillStyle = '#00274C'; ctx.font = '12px sans-serif'; ctx.textAlign = 'right';
  for (let k = 0; k <= 4; k++) {
    const vy = y0 + (k / 4) * (y1 - y0);
    const py = yToPx(vy);
    ctx.fillText(vy.toFixed(3), m.left - 6, py + 4);
  ctx.strokeStyle = '#e9eef6'; ctx.beginPath(); ctx.moveTo(m.left, py); ctx.lineTo(m.left + w, py); ctx.stroke();
  }
  // line
  ctx.strokeStyle = '#00274C'; ctx.lineWidth = 1.5; ctx.beginPath();
  for (let i = 0; i < n; i++) {
    const x = xToPx(i);
    const y = yToPx(dataY[i]);
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.stroke();
}

// (line-plot drawing helper placed above)
// (placed after drawLinePlot so it's available)
