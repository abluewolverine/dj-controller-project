import React, { useState, useRef } from 'react';
import { pushLog } from '../utils/devLog';
import ParamDisplay from './ParamDisplay';
import ElementInfo from './ElementInfo';

export default function Controls({ onRun, running, simParams }) {
  // theme toggling: read stored preference or default to 'default'
  const [theme, setTheme] = useState(() => {
    try {
      return window.localStorage.getItem('theme') || 'default';
    } catch (e) { return 'default'; }
  });

  // Live Guide Mode state
  const [guideMode, setGuideMode] = useState(() => {
    try {
      return window.localStorage.getItem('guideMode') === 'true';
    } catch (e) { return false; }
  });

  // Tooltip state
  const [activeTooltip, setActiveTooltip] = useState(null);

  // apply theme on mount and when it changes
  React.useEffect(() => {
    try {
      if (theme === 'um') document.documentElement.setAttribute('data-theme', 'um');
      else document.documentElement.removeAttribute('data-theme');
      window.localStorage.setItem('theme', theme);
    } catch (e) {}
  }, [theme]);

  // Save guide mode preference
  React.useEffect(() => {
    try {
      window.localStorage.setItem('guideMode', guideMode.toString());
    } catch (e) {}
  }, [guideMode]);

  // Guide explanations for each parameter
  const guideExplanations = {
    protons: {
      title: "Protons (Atomic Number)",
      description: "The number of protons determines the element type and nuclear charge. More protons = stronger nuclear attraction, affecting electron positions.",
      context: (value, neutrons, electrons) => {
        const atomicNum = value;
        const element = getElementName(atomicNum);
        if (atomicNum === 0) return "No protons = no atom exists";
        if (atomicNum !== electrons) return `Ion: ${atomicNum > electrons ? 'positive' : 'negative'} charge affects stability`;
        return `${element}: Nuclear charge ${atomicNum} strongly attracts ${electrons} electrons`;
      }
    },
    neutrons: {
      title: "Neutrons (Nuclear Stability)",
      description: "Neutrons provide nuclear stability without adding charge. The neutron-to-proton ratio affects nuclear forces and particle behavior.",
      context: (value, protons) => {
        if (protons === 0) return "No nucleus without protons";
        const ratio = value / protons;
        if (ratio < 0.5) return "Too few neutrons: nucleus likely unstable";
        if (ratio > 2) return "Too many neutrons: highly unstable, radioactive";
        if (ratio === 1) return "Equal neutrons/protons: stable for light elements";
        return `N/P ratio ${ratio.toFixed(2)}: ${ratio > 1.5 ? 'heavy' : 'stable'} nucleus`;
      }
    },
    electrons: {
      title: "Electrons (Quantum Behavior)",
      description: "Electrons exist in probability clouds around the nucleus. Their quantum behavior creates the wave patterns you see in the simulation.",
      context: (value, protons) => {
        if (value === protons) return "Neutral atom: electron clouds balanced by nuclear charge";
        if (value > protons) return `Negative ion: excess electrons create larger, looser orbital clouds`;
        if (value < protons) return `Positive ion: fewer electrons pulled tighter to nucleus`;
        return `${Math.abs(value - protons)} charge difference affects orbital shapes`;
      }
    },
    field: {
      title: "Electric Field (External Force)",
      description: "External electric field distorts electron probability clouds. Stronger fields shift where particles are likely to be found.",
      context: (value) => {
        if (value === 0) return "No external field: natural atomic behavior";
        if (Math.abs(value) < 5) return "Weak field: slight distortion of electron clouds";
        if (Math.abs(value) > 20) return "Strong field: dramatic shifts in probability distributions";
        return `Field strength ${value}: ${value > 0 ? 'pushes' : 'pulls'} electron clouds`;
      }
    },
    temperature: {
      title: "Temperature (Thermal Motion)",
      description: "Higher temperature increases particle motion and uncertainty. Position 'fuzziness' increases with thermal energy.",
      context: (value) => {
        if (value < 100) return "Very cold: particles have well-defined positions";
        if (value < 300) return "Room temperature: moderate thermal motion";
        if (value > 1000) return "High temperature: particles move rapidly, positions very uncertain";
        return `${value}K: thermal energy ${value > 500 ? 'dominates' : 'influences'} particle behavior`;
      }
    }
  };

  function getElementName(atomicNumber) {
    const elements = ['None', 'Hydrogen', 'Helium', 'Lithium', 'Beryllium', 'Boron', 'Carbon', 'Nitrogen', 'Oxygen', 'Fluorine', 'Neon'];
    return elements[atomicNumber] || `Element ${atomicNumber}`;
  }
  const [nProtons, setNProtons] = useState(1);
  const [nNeutrons, setNNeutrons] = useState(0);
  const [nElectrons, setNElectrons] = useState(1);
  const [E, setE] = useState(0);
  const [temp, setTemp] = useState(300);
  const [mode, setMode] = useState('quantum');
  const [T, setT] = useState(80);
  const [decoherence, setDecoherence] = useState('');
  const [activePreset, setActivePreset] = useState(null);

  // Small numeric "knob" component: compact pill with up/down ticks and click-to-edit
  function NumericKnob({ value, onChange, min = -Infinity, max = Infinity, step = 1, precision = 0 }) {
    const [editing, setEditing] = useState(false);
    const [pressed, setPressed] = useState(false);
    const inputRef = useRef(null);

    function commit(v) {
      let nv = Number(v);
      if (Number.isNaN(nv)) nv = 0;
      nv = Math.max(min, Math.min(max, nv));
      if (precision > 0) nv = Number(nv.toFixed(precision));
      onChange(nv);
    }

    return (
      <div className={`knob ${pressed ? 'pressed' : ''}`} onMouseUp={() => setPressed(false)} onMouseLeave={() => setPressed(false)}>
        {!editing ? (
          <div className="knob-pill" onClick={() => { setEditing(true); setTimeout(() => inputRef.current && inputRef.current.focus(), 0); }}>
            <div className="knob-value">{String(value)}</div>
            <div className="knob-buttons">
              <button className="knob-tick" onMouseDown={() => { setPressed(true); commit(value + step); }} onClick={(e) => e.stopPropagation()} title="Increase">▲</button>
              <button className="knob-tick" onMouseDown={() => { setPressed(true); commit(value - step); }} onClick={(e) => e.stopPropagation()} title="Decrease">▼</button>
            </div>
          </div>
        ) : (
          <input
            ref={inputRef}
            className="knob-input"
            defaultValue={String(value)}
            onBlur={(e) => { setEditing(false); commit(e.target.value); }}
            onKeyDown={(e) => { if (e.key === 'Enter') { setEditing(false); commit(e.target.value); } if (e.key === 'Escape') { setEditing(false); } }}
          />
        )}
      </div>
    );
  }

  // Tooltip component for guide mode
  function GuideTooltip({ id, explanation, contextValue, contextParams = [] }) {
    if (!guideMode || activeTooltip !== id) return null;
    
    const contextText = typeof explanation.context === 'function' 
      ? explanation.context(contextValue, ...contextParams)
      : '';

    return (
      <div className="guide-tooltip">
        <div className="tooltip-header">
          <h4>{explanation.title}</h4>
          <button className="tooltip-close" onClick={() => setActiveTooltip(null)}>×</button>
        </div>
        <p className="tooltip-description">{explanation.description}</p>
        {contextText && (
          <div className="tooltip-context">
            <strong>Current Status:</strong> {contextText}
          </div>
        )}
        <div className="tooltip-position-explanation">
          <strong>About Positions:</strong> Position values represent probability peaks where particles are most likely to be detected. Higher numbers indicate greater distance from the nucleus center.
        </div>
      </div>
    );
  }

  return (
    <div className="controls">
      <div className="controls-header">
        <h4>Controls</h4>
        <div className="guide-mode-toggle">
          <label className="toggle-switch">
            <input 
              type="checkbox" 
              checked={guideMode} 
              onChange={(e) => setGuideMode(e.target.checked)}
            />
            <span className="toggle-slider"></span>
            <span className="toggle-label">Live Guide Mode</span>
          </label>
        </div>
      </div>
      
      {/* element lookup: show above all parameter controls */}
      <div style={{ marginBottom: 8 }}>
        <ElementInfo nProtons={nProtons} nNeutrons={nNeutrons} nElectrons={nElectrons} />
        {guideMode && (
          <div className="guide-hint">
            💡 Hover over parameter labels for detailed explanations
          </div>
        )}
      </div>

      <div className="param-group">
        <label 
          className={`param-label ${guideMode ? 'guide-enabled' : ''}`}
          onMouseEnter={() => guideMode && setActiveTooltip('protons')}
          onMouseLeave={() => setActiveTooltip(null)}
        >
          Protons:
          {guideMode && <span className="guide-indicator">ℹ️</span>}
          <NumericKnob value={nProtons} onChange={(v) => setNProtons(v == null ? 0 : v)} min={0} step={1} />
        </label>
        <GuideTooltip 
          id="protons" 
          explanation={guideExplanations.protons} 
          contextValue={nProtons} 
          contextParams={[nNeutrons, nElectrons]}
        />
      </div>

      <div className="param-group">
        <label 
          className={`param-label ${guideMode ? 'guide-enabled' : ''}`}
          onMouseEnter={() => guideMode && setActiveTooltip('neutrons')}
          onMouseLeave={() => setActiveTooltip(null)}
        >
          Neutrons:
          {guideMode && <span className="guide-indicator">ℹ️</span>}
          <NumericKnob value={nNeutrons} onChange={(v) => setNNeutrons(v == null ? 0 : v)} min={0} step={1} />
        </label>
        <GuideTooltip 
          id="neutrons" 
          explanation={guideExplanations.neutrons} 
          contextValue={nNeutrons} 
          contextParams={[nProtons]}
        />
      </div>

      <div className="param-group">
        <label 
          className={`param-label ${guideMode ? 'guide-enabled' : ''}`}
          onMouseEnter={() => guideMode && setActiveTooltip('electrons')}
          onMouseLeave={() => setActiveTooltip(null)}
        >
          Electrons:
          {guideMode && <span className="guide-indicator">ℹ️</span>}
          <NumericKnob value={nElectrons} onChange={(v) => setNElectrons(v == null ? 0 : v)} min={0} step={1} />
        </label>
        <GuideTooltip 
          id="electrons" 
          explanation={guideExplanations.electrons} 
          contextValue={nElectrons} 
          contextParams={[nProtons]}
        />
      </div>

      <div className="param-group">
        <label 
          className={`param-label ${guideMode ? 'guide-enabled' : ''}`}
          onMouseEnter={() => guideMode && setActiveTooltip('field')}
          onMouseLeave={() => setActiveTooltip(null)}
        >
          Field (E):
          {guideMode && <span className="guide-indicator">ℹ️</span>}
          <NumericKnob value={E} onChange={(v) => setE(v == null ? 0 : v)} step={1} precision={2} />
        </label>
        <GuideTooltip 
          id="field" 
          explanation={guideExplanations.field} 
          contextValue={E}
        />
      </div>

      <div className="param-group">
        <label 
          className={`param-label ${guideMode ? 'guide-enabled' : ''}`}
          onMouseEnter={() => guideMode && setActiveTooltip('temperature')}
          onMouseLeave={() => setActiveTooltip(null)}
        >
          Temperature:
          {guideMode && <span className="guide-indicator">ℹ️</span>}
          <NumericKnob value={temp} onChange={(v) => setTemp(v == null ? 0 : v)} step={1} />
        </label>
        <GuideTooltip 
          id="temperature" 
          explanation={guideExplanations.temperature} 
          contextValue={temp}
        />
      </div>

      <label>
        Timesteps (T):
        <NumericKnob value={T} onChange={(v) => setT(v == null ? 1 : v)} min={1} step={1} />
      </label>

      <label>
        Mode:
        <select value={mode} onChange={(e) => setMode(e.target.value)}>
          <option value="quantum">Quantum (approx)</option>
          <option value="classical">Classical (approx)</option>
        </select>
      </label>

      <label>
        Decoherence override (0–1, blank = auto):
        <input type="number" min="0" max="1" step="0.01" value={decoherence} onChange={(e) => setDecoherence(e.target.value)} />
      </label>

      <div style={{ marginTop: 10 }}>
          <button className="button" onClick={() => onRun({ nProtons, nNeutrons, nElectrons, E, temp, mode, T, decoherenceOverride: decoherence === '' ? null : Number(decoherence) })} disabled={running}>
            {running ? 'Running...' : 'Run'}
          </button>
          <button className="button" style={{ marginLeft: 8, background: theme === 'um' ? 'linear-gradient(180deg,var(--um-maize),var(--card-dark))' : undefined }} onClick={() => setTheme(theme === 'um' ? 'default' : 'um')}>Theme: {theme === 'um' ? 'Michigan' : 'Default'}</button>
      </div>
      <div style={{ marginTop: 12 }}>
        <strong>Presets:</strong>
        <div className="presets" style={{ marginTop: 8 }}>
          <button
            className="preset button"
            onClick={() => {
              const opts = { mode: 'quantum', nProtons: 1, nNeutrons: 0, nElectrons: 1, E: 0, temp: 300, T: 100, decoherenceOverride: null };
              setNProtons(opts.nProtons); setNNeutrons(opts.nNeutrons); setNElectrons(opts.nElectrons); setE(opts.E); setTemp(opts.temp); setMode(opts.mode); setT(opts.T); setDecoherence('');
              setActivePreset('hydrogen');
              pushLog('Preset applied: hydrogen', opts);
              onRun(opts);
            }}
            disabled={running}
            style={ activePreset === 'hydrogen' ? { boxShadow: '0 0 0 3px rgba(0,39,76,0.12)' } : undefined }
          >
            Hydrogen (H)
          </button>

          <button
            className="preset button"
            onClick={() => {
              const opts = { mode: 'quantum', nProtons: 2, nNeutrons: 2, nElectrons: 2, E: 0, temp: 300, T: 100, decoherenceOverride: null };
              setNProtons(opts.nProtons); setNNeutrons(opts.nNeutrons); setNElectrons(opts.nElectrons); setE(opts.E); setTemp(opts.temp); setMode(opts.mode); setT(opts.T); setDecoherence('');
              setActivePreset('helium');
              pushLog('Preset applied: helium', opts);
              onRun(opts);
            }}
            disabled={running}
            style={ activePreset === 'helium' ? { boxShadow: '0 0 0 3px rgba(0,39,76,0.12)' } : undefined }
          >
            Helium (He)
          </button>

          <button
            className="preset button"
            onClick={() => {
              const opts = { mode: 'quantum', nProtons: 6, nNeutrons: 6, nElectrons: 6, E: 0, temp: 300, T: 100, decoherenceOverride: null };
              setNProtons(opts.nProtons); setNNeutrons(opts.nNeutrons); setNElectrons(opts.nElectrons); setE(opts.E); setTemp(opts.temp); setMode(opts.mode); setT(opts.T); setDecoherence('');
              setActivePreset('carbon');
              pushLog('Preset applied: carbon', opts);
              onRun(opts);
            }}
            disabled={running}
            style={ activePreset === 'carbon' ? { boxShadow: '0 0 0 3px rgba(0,39,76,0.12)' } : undefined }
          >
            Carbon (C)
          </button>

          <button
            className="preset button"
            onClick={() => {
              const opts = { mode: 'quantum', nProtons: 8, nNeutrons: 8, nElectrons: 8, E: 0, temp: 300, T: 100, decoherenceOverride: null };
              setNProtons(opts.nProtons); setNNeutrons(opts.nNeutrons); setNElectrons(opts.nElectrons); setE(opts.E); setTemp(opts.temp); setMode(opts.mode); setT(opts.T); setDecoherence('');
              setActivePreset('oxygen');
              pushLog('Preset applied: oxygen', opts);
              onRun(opts);
            }}
            disabled={running}
            style={ activePreset === 'oxygen' ? { boxShadow: '0 0 0 3px rgba(0,39,76,0.12)' } : undefined }
          >
            Oxygen (O)
          </button>

          <button
            className="preset button"
            title="Fun preset: Higgs boson (very massive, short-lived) — modeled with a large field and high decoherence"
            onClick={() => {
              const opts = { mode: 'quantum', nProtons: 0, nNeutrons: 0, nElectrons: 0, E: 1000, temp: 1, T: 200, decoherenceOverride: 0.9 };
              setNProtons(opts.nProtons); setNNeutrons(opts.nNeutrons); setNElectrons(opts.nElectrons); setE(opts.E); setTemp(opts.temp); setMode(opts.mode); setT(opts.T); setDecoherence(String(opts.decoherenceOverride));
              setActivePreset('higgs');
              pushLog('Preset applied: higgs-boson (fun analogue)', opts);
              onRun(opts);
            }}
            disabled={running}
            style={ activePreset === 'higgs' ? { boxShadow: '0 0 0 3px rgba(0,39,76,0.12)' } : undefined }
          >
            Higgs boson (fun)
          </button>

          <button
            className="preset button"
            title="Fun preset: Hawking radiation (thermal emission) — modeled with very high temperature"
            onClick={() => {
              const opts = { mode: 'classical', nProtons: 0, nNeutrons: 0, nElectrons: 2, E: 0, temp: 1e6, T: 180, decoherenceOverride: 0.6 };
              setNProtons(opts.nProtons); setNNeutrons(opts.nNeutrons); setNElectrons(opts.nElectrons); setE(opts.E); setTemp(opts.temp); setMode(opts.mode); setT(opts.T); setDecoherence(String(opts.decoherenceOverride));
              setActivePreset('hawking');
              pushLog('Preset applied: hawking-radiation (fun analogue)', opts);
              onRun(opts);
            }}
            disabled={running}
            style={ activePreset === 'hawking' ? { boxShadow: '0 0 0 3px rgba(0,39,76,0.12)' } : undefined }
          >
            Hawking radiation (fun)
          </button>

          <button
            className="preset button"
            title="Fun preset: Photon (Einstein) — massless neutral particle analogue with low decoherence"
            onClick={() => {
              const opts = { mode: 'quantum', nProtons: 0, nNeutrons: 0, nElectrons: 0, E: 10, temp: 300, T: 120, decoherenceOverride: 0 };
              setNProtons(opts.nProtons); setNNeutrons(opts.nNeutrons); setNElectrons(opts.nElectrons); setE(opts.E); setTemp(opts.temp); setMode(opts.mode); setT(opts.T); setDecoherence(String(opts.decoherenceOverride));
              setActivePreset('einstein-particle');
              pushLog('Preset applied: photon (Einstein analogue)', opts);
              onRun(opts);
            }}
            disabled={running}
            style={ activePreset === 'einstein-particle' ? { boxShadow: '0 0 0 3px rgba(255,203,5,0.12)' } : undefined }
          >
            Photon (Einstein)
          </button>
        </div>
      </div>

      <div style={{ marginTop: 12 }}>
        <ParamDisplay simParams={simParams} />
      </div>
    </div>
  );
}
