import React from 'react';
import Simulation from './components/Simulation';
import './styles/App.css';

function App() {
  return (
    <div className="App">
  <h1 className="app-title">Particle superposition simulator</h1>
      <Simulation />
    </div>
  );
}

export default App;