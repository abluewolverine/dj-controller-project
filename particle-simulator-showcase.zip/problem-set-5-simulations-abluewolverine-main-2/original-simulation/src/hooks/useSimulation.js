import { useCallback, useState } from 'react';
import physicalToSimParams from '../utils/physicalParams';
import { pushLog } from '../utils/devLog';

// A hook that provides a run() function to execute either a classical
// random-walk approximation or a small quantum-inspired coined walk with
// a simple decoherence parameter. Returns { run, running, result }.
export default function useSimulation() {
    const [running, setRunning] = useState(false);
    const [result, setResult] = useState(null);

    const linspace = (n, start, step = 1) => Array.from({ length: n }, (_, i) => start + i * step);

    const run = useCallback(async (options = {}) => {
        setRunning(true);
        try {
            const {
                nProtons = 1,
                nNeutrons = 0,
                nElectrons = 1,
                E = 0,
                temp = 300,
                mode = 'quantum',
                T = 100,
                latticeRadius = 100,
                decoherenceOverride = null
            } = options;

            pushLog('Run started', { options });
            const simParams = physicalToSimParams({ nProtons, nNeutrons, nElectrons, E, temp });
            pushLog('Derived simParams', { simParams });
            if (decoherenceOverride != null) simParams.decoherence = Math.max(0, Math.min(1, decoherenceOverride));

            if (mode === 'classical') {
                // Gaussian approximation for final distribution
                const R = latticeRadius;
                const positions = linspace(2 * R + 1, -R, 1);
                const mean = simParams.bias * T;
                const variance = Math.max(1e-9, simParams.stepVariance * T);
                const sigma = Math.sqrt(variance);
                const pmf = {};
                const normConst = 1 / (Math.sqrt(2 * Math.PI) * sigma);
                positions.forEach((x) => {
                    const z = (x - mean) / sigma;
                    pmf[x] = Math.exp(-0.5 * z * z) * normConst;
                });
                // renormalize to discrete sum
                const total = Object.values(pmf).reduce((a, b) => a + b, 0);
                Object.keys(pmf).forEach((k) => (pmf[k] /= total));

                        setResult({ mode: 'classical', simParams, T, pmf, mean, variance, nProtons, nNeutrons, nElectrons });
                        pushLog('Classical run finished', { mean, variance });
                setRunning(false);
                return;
            }

                    // quantum-inspired coined walk on 1D lattice [-R .. R]
            const R = latticeRadius;
            const L = 2 * R + 1;
            const center = R;
                    const zeros = () => Array.from({ length: L }, () => ({ re: 0, im: 0 }));
                    let amp0 = zeros();
                    let amp1 = zeros();
                    amp0[center] = { re: 1.0, im: 0.0 };

                    // helper functions and wavefield record containers
                    const hadamard = (a0, a1) => {
                        const s = 1 / Math.SQRT2;
                        const b0 = { re: s * (a0.re + a1.re), im: s * (a0.im + a1.im) };
                        const b1 = { re: s * (a0.re - a1.re), im: s * (a0.im - a1.im) };
                        return [b0, b1];
                    };

                    const cadd = (a, b) => ({ re: a.re + b.re, im: a.im + b.im });
                    const cmulScalar = (a, s) => ({ re: a.re * s, im: a.im * s });
                    const cabs2 = (a) => a.re * a.re + a.im * a.im;

                    const gamma = simParams.decoherence;

                    // Record wavefield over time: re[t][i], im[t][i], prob[t][i]
                    const reSeries = [];
                    const imSeries = [];
                    const probSeries = [];

                    const pushSnapshot = () => {
                        const reRow = new Float32Array(L);
                        const imRow = new Float32Array(L);
                        const probRow = new Float32Array(L);
                        for (let i = 0; i < L; i++) {
                            reRow[i] = amp0[i].re + amp1[i].re;
                            imRow[i] = amp0[i].im + amp1[i].im;
                            probRow[i] = cabs2(amp0[i]) + cabs2(amp1[i]);
                        }
                        reSeries.push(reRow);
                        imSeries.push(imRow);
                        probSeries.push(probRow);
                    };

                    // initial snapshot t=0
                    pushSnapshot();

                    for (let t = 0; t < T; t++) {
                const afterC0 = zeros();
                const afterC1 = zeros();
                for (let x = 0; x < L; x++) {
                    const [b0, b1] = hadamard(amp0[x], amp1[x]);
                    afterC0[x] = b0;
                    afterC1[x] = b1;
                }
                const shifted0 = zeros();
                const shifted1 = zeros();
                for (let x = 0; x < L; x++) {
                    if (x + 1 < L) shifted0[x + 1] = cadd(shifted0[x + 1], afterC0[x]);
                    if (x - 1 >= 0) shifted1[x - 1] = cadd(shifted1[x - 1], afterC1[x]);
                }
                amp0 = shifted0;
                amp1 = shifted1;

                if (gamma > 1e-12) {
                    for (let x = 0; x < L; x++) {
                        const a0 = amp0[x], a1 = amp1[x];
                        const mag0 = Math.sqrt(cabs2(a0));
                        const mag1 = Math.sqrt(cabs2(a1));
                        amp0[x] = { re: (1 - gamma) * a0.re + gamma * mag0, im: (1 - gamma) * a0.im };
                        amp1[x] = { re: (1 - gamma) * a1.re + gamma * mag1, im: (1 - gamma) * a1.im };
                    }
                    let total = 0;
                    for (let x = 0; x < L; x++) total += cabs2(amp0[x]) + cabs2(amp1[x]);
                    const norm = Math.sqrt(Math.max(total, 1e-12));
                    for (let x = 0; x < L; x++) {
                        amp0[x] = cmulScalar(amp0[x], 1 / norm);
                        amp1[x] = cmulScalar(amp1[x], 1 / norm);
                    }
                }
                            // snapshot after this timestep
                            pushSnapshot();
            }

                        const pmf = {};
            let mean = 0;
            let variance = 0;
            let totalProb = 0;
            for (let i = 0; i < L; i++) {
                const p = cabs2(amp0[i]) + cabs2(amp1[i]);
                const pos = i - R;
                pmf[pos] = p;
                mean += pos * p;
                totalProb += p;
            }
            for (const k of Object.keys(pmf)) pmf[k] /= totalProb;
            mean /= totalProb;
            for (const k of Object.keys(pmf)) {
                const pos = Number(k);
                variance += (pos - mean) ** 2 * pmf[k];
            }

                            setResult({ mode: 'quantum', simParams, T, pmf, mean, variance, positions: linspace(L, -R, 1), wavefield: { re: reSeries, im: imSeries, prob: probSeries }, nProtons, nNeutrons, nElectrons });
                            pushLog('Quantum run finished', { mean, variance, totalProb_mean: probSeries.reduce((a,b)=>a+Array.from(b).reduce((x,y)=>x+y,0),0)/probSeries.length });
        } catch (err) {
                            console.error('Simulation error', err);
                            pushLog('Simulation error', { error: String(err) });
                            setResult({ error: String(err) });
        } finally {
            setRunning(false);
        }
    }, []);

    return { run, running, result };
}